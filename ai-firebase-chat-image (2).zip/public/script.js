const firebaseConfig = {
  apiKey: "AIzaSyCWdoHnwSfSeOVtiSuRDlKoOszaEpzoork",
  authDomain: "pbf-newspp.firebaseapp.com",
  databaseURL: "https://pbf-newspp-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "pbf-newspp",
  storageBucket: "pbf-newspp.appspot.com",
  messagingSenderId: "88186159677",
  appId: "1:88186159677:web:4acbf313e00bbd403f6054"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const storage = firebase.storage();

firebase.auth().signInAnonymously().catch(console.error);

function sendChat() {
  const input = document.getElementById("chatInput");
  const prompt = input.value;
  input.value = "";
  fetch("/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt })
  })
    .then(res => res.json())
    .then(data => {
      const div = document.createElement("div");
      div.textContent = "AI: " + data.reply;
      document.getElementById("chatBox").appendChild(div);
      db.ref("chats").push({ prompt, reply: data.reply });
    });
}

function generateImage() {
  const input = document.getElementById("imagePrompt");
  const prompt = input.value;
  input.value = "";
  fetch("/generateImage", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt })
  })
    .then(res => res.json())
    .then(data => {
      const img = document.createElement("img");
      img.src = data.imageUrl;
      img.width = 256;
      document.getElementById("imageResult").appendChild(img);

      // Upload URL to Firebase Storage
      fetch(data.imageUrl)
        .then(res => res.blob())
        .then(blob => {
          const ref = storage.ref().child("images/" + Date.now() + ".png");
          ref.put(blob);
        });
    });
}