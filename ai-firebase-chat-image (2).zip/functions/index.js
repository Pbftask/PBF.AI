const functions = require("firebase-functions");
const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: "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",
});
const openai = new OpenAIApi(configuration);

exports.chat = functions.https.onRequest(async (req, res) => {
  const prompt = req.body.prompt;
  try {
    const completion = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
    });
    res.json({ reply: completion.data.choices[0].message.content });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

exports.generateImage = functions.https.onRequest(async (req, res) => {
  const prompt = req.body.prompt;
  try {
    const response = await openai.createImage({
      prompt: prompt,
      n: 1,
      size: "512x512",
    });
    res.json({ imageUrl: response.data.data[0].url });
  } catch (error) {
    res.status(500).send(error.message);
  }
});